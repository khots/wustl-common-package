package edu.wustl.common.querysuite.queryengine.impl;

public class SqlKeyWords {
    public static final String SELECT = "select ";
    
    public static final String SELECT_DISTINCT = "select distinct ";
    
    public static final String WHERE = " where ";
    
    public static final String FROM = " from ";
    
    public static final String LEFT_JOIN = " left join ";
    
    public static final String INNER_JOIN = " inner join ";
    
    public static final String ON = " on ";
}
