
package edu.wustl.common.querysuite.queryobject;

/**
 * @author prafull_kadam
 */
public interface IConstraintEntity extends IQueryEntity
{

}
