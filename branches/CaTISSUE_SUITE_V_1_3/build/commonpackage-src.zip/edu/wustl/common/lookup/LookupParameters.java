/**
 * <p>Title: LookupParameters Class>
 * <p>Description:	This is the Marker Interface used for sending parameters to Lookup Logic.</p>
 * Copyright:    Copyright (c) year
 * Company: Washington University, School of Medicine, St. Louis.
 * @author vaishali_khandelwal
 */
package edu.wustl.common.lookup;


public interface LookupParameters
{

}
