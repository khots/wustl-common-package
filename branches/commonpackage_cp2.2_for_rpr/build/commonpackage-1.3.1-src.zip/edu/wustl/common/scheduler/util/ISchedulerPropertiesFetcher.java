package edu.wustl.common.scheduler.util;

import java.util.Map;


public interface ISchedulerPropertiesFetcher
{
	public Map<String,Object> getSchedulerPropertiesMap();
}
