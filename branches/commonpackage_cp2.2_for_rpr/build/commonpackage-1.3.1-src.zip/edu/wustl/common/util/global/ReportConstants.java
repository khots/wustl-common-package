/**
 * 
 */
package edu.wustl.common.util.global;


/**
 * @author skhot
 *
 */
public class ReportConstants
{
	public static final String PARTICIPANT_OBJECT = "participantObject";
	public static final String CP_ID = "cpId";
	public static final String PARTICIPANT_ID = "participantId";
	public static final String IS_SYSTEM_DASHBOARD = "isSystemDashboard";
	public static final String TRUE = "true";
	public static final String REDIRECT = "redirect";
	public static final String SUCCESS = "success";
	public static final String CP_SEARCH_CP_ID = "cpSearchCpId";
	public static final String REPORT_NAME_LIST = "reportNameList";
	public static final String DOUBLE_QUOTE = "";
	
}
