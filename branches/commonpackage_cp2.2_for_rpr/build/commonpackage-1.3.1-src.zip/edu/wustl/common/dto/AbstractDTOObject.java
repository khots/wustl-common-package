package edu.wustl.common.dto;

public abstract class AbstractDTOObject {

	public abstract Long getId();
	public abstract int getRelatedFormId();
}
