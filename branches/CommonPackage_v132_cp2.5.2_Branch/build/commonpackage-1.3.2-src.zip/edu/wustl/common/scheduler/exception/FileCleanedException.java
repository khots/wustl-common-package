
package edu.wustl.common.scheduler.exception;

public class FileCleanedException extends Exception

{
	private static final long serialVersionUID = 4645473497741710501L;

	public FileCleanedException(String message)
	{
		super(message);
	}
}
