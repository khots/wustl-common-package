/**
 *
 */
package edu.wustl.common.processor.datacarrier;

/**
 * @author vishvesh_mulay
 *
 */
public interface OutputDataInterface extends DataInterface
{

}
