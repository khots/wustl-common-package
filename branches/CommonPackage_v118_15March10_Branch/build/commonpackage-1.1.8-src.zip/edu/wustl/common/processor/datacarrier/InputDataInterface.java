package edu.wustl.common.processor.datacarrier;

public interface InputDataInterface extends DataInterface
{

}
