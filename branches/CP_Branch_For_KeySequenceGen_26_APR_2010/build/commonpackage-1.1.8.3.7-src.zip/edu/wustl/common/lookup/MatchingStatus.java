package edu.wustl.common.lookup;

/**
 *
 * MatchingStatus enum.
 *
 */
public enum MatchingStatus
{
	/**
	 * Matching Status values.
	 */
	EXACT, PARTIAL, NOMATCH;
}

