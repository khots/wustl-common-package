/*
 * Created on Jun 29, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.wustl.common.util.test;

import org.apache.log4j.PropertyConfigurator;

import junit.framework.TestCase;
import edu.wustl.common.util.CVSTagReader;
import edu.wustl.common.util.global.Variables;
import edu.wustl.common.util.logger.Logger;


/**
 * @author kapil_kaveeshwar
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CVSTagReaderTestcase extends TestCase
{
	public CVSTagReaderTestcase()
	{
		super("CVSTagReaderTestcase");
	}
	
	public void setUp()
	{
		Variables.applicationHome = System.getProperty("user.dir");
		Logger.out = org.apache.log4j.Logger.getLogger("");
		PropertyConfigurator.configure(Variables.applicationHome+"/Logger.properties");
	}
	public void testReadTagPositive()
	{
		CVSTagReader cvsTagReader = new CVSTagReader();
		String tag = cvsTagReader.readTag("ApplicationVersionInfo.txt");
		assertEquals("Test_tag",tag);
	}

	public void testReadTagFileNotFound()
	{
		CVSTagReader cvsTagReader = new CVSTagReader();
		String tag = cvsTagReader.readTag("ApplicationVersionInfo1.txt");
		assertEquals(null,tag);
	}

	public void testReadTagWrongPattern()
	{
		CVSTagReader cvsTagReader = new CVSTagReader();
		String tag = cvsTagReader.readTag("ApplicationVersionInfo2.txt");
		assertEquals(null,tag);
	}
}