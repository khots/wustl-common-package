package edu.wustl.common.vo;

import javax.mail.MessagingException;

import edu.wustl.common.exception.BizLogicException;
import edu.wustl.common.exception.ErrorKey;
import edu.wustl.common.util.global.EmailDetails;
import edu.wustl.common.util.global.SendEmail;


public class Test
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		EmailDetails emailDetails= new EmailDetails();
		emailDetails.addToAddress("to@test.com");
		//emailDetails.addCcAddress("cc@test.com");
		emailDetails.setSubject("subject");
		emailDetails.setBody("Body");
		SendEmail email=null;
		try
		{
			email = new SendEmail("mail.persistent.co.in", "from@test.com");
		}
		catch (MessagingException e)
		{
			e.printStackTrace();
		}
		boolean startus= email.sendMail(emailDetails);
		//System.out.println("startus:"+startus);
		

	}

}
