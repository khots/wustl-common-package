package edu.wustl.common.lookup;

public class LookupResult
{
	Object object;
	Double probablity;
	
	public Object getObject()
	{
		return object;
	}
	
	public void setObject(Object object)
	{
		this.object = object;
	}
	
	public Double getProbablity()
	{
		return probablity;
	}
	
	public void setProbablity(Double probablity)
	{
		this.probablity = probablity;
	}
	
	
}
