package edu.wustl.common.lookup;


public interface LookupParameters
{

}
