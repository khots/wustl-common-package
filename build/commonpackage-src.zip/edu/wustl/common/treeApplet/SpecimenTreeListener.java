package edu.wustl.common.treeApplet;

import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.event.MouseEvent;

import javax.swing.JTree;
import javax.swing.event.MouseInputListener;
import javax.swing.tree.DefaultMutableTreeNode;

import netscape.javascript.JSObject;
import edu.wustl.common.tree.SpecimenTreeNode;
import edu.wustl.common.util.global.Constants;


/**
 * @author ramya_nagraj
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class SpecimenTreeListener extends AppletTreeListener
{

	 private String type;
	 
	 private String specimenClass;
	 
	 private String disabled;
	 
	 public String getDisabled() {
		return disabled;
	}

	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}

	/**
	  * public No-Args Constructor.
	  *
	  */
	 public SpecimenTreeListener()
	 {
		 super();
	 }
	 
	 /**
	  * public parametrized Constructor to set the type of specimen node.
	  *
	  */
	 public SpecimenTreeListener(String nodeType,String nodeClass,String disabled)
	 {
		 type = nodeType;
		 specimenClass = nodeClass;
		 this.disabled = disabled;
	 }
	 

	public void displayClickedSpecimenNode() 
	{
		SpecimenTreeNode treeNode = (SpecimenTreeNode) node
        .getUserObject();
    	
		//If Root node selected then do nothing
		if(treeNode.toString().equals(Constants.SPECIMEN_TREE_ROOT_NAME))
		{
			//return;
		}	
		//If selected node is not of given type and class, then do nothing.
		if(!treeNode.getType().equalsIgnoreCase(type) && !treeNode.getSpecimenClass().equalsIgnoreCase(specimenClass))
		{
			return;
		}
		//if(treeNode.getChildNodes()==null || treeNode.getChildNodes().size()==0)
		
		//If selected node is of given type and class, then set its value in dropdown and the dropdown is not disabled.
		else if(treeNode.getType().equalsIgnoreCase(type) && treeNode.getSpecimenClass().equalsIgnoreCase(specimenClass) && disabled.equalsIgnoreCase("false"))
		{
				System.out.println("...treeNode.getType() " + treeNode.getType());
				System.out.println("...treeNode.getSpecimenClass()  " + treeNode.getSpecimenClass());
				System.out.println("...disabled = " + disabled);
			setValue="setParentWindowValue('"+propertyName+"','"+treeNode.toString()+"')";
		}
		else
		{
			return;
		}
		
	}

}
