package edu.wustl.common.datahandler;

/**
 *
 * @author
 *
 */
public enum HandlerTypeEnum
{
	/**
	 *
	 */
	TEXT, CSV
};
