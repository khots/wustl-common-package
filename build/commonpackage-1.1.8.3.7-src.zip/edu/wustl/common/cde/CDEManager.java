/*
 * Created on Jul 26, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.wustl.common.cde;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import edu.wustl.common.beans.NameValueBean;
import edu.wustl.common.cde.xml.XMLCDE;
import edu.wustl.common.cde.xml.XMLCDECacheType;
import edu.wustl.common.util.global.CommonServiceLocator;
import edu.wustl.common.util.global.Constants;
import edu.wustl.common.util.logger.Logger;

/**
 * @author kapil_kaveeshwar
 *  This is a communication link between the caTISSUE Core Application and the caDSR interface.
 * */
public final class CDEManager // NOPMD
{
	/**
	 *
	 */
	public static CDEManager cdeManager;
	/**
	 *
	 * @throws Exception throw Exception
	 */
	public static void init() throws Exception
	{
	    Logger.out.debug("Initializing CDE Manager");
		//Singleton instance of CDEManager
		cdeManager = new CDEManager();
		cdeManager.loadCDEInMemory();
//		cdeManager.refreshCache();
	}
	/**
	 *
	 * @return CDEManager object.
	 */
	public static CDEManager getCDEManager()
	{
		return cdeManager;
	}
	/**
	 * A map between CDE name to its XML Object.
	 */
	private final Map cdeXMLMAP;
	/**
	 *
	 */
	private CDEHandler cdeHandler;
	/**
	 *
	 * @throws Exception throw Exception object.
	 */
	private CDEManager() throws Exception // NOPMD
	{
		cdeXMLMAP = new HashMap();
		try
		{
			/**
			 * create a JAXBContext capable of handling classes
			 * generated into the edu.wustl.common.cde.xml package
			 */
            JAXBContext jaxbContextObject = JAXBContext.newInstance(Constants.CDE_XML_PACKAGE_PATH);
            /**
             *  create an Unmarshaller which provides the ability to convert
             *   XML data into a tree of Java content objects.
             */
            Unmarshaller unmarshallerObject = jaxbContextObject.createUnmarshaller();
            /**
             *  unmarshal a root instance document into a tree of Java content
             *  objects composed of classes from the pspl.cde package.
             */
            String appHome=CommonServiceLocator.getInstance().getAppHome();
			JAXBElement<XMLCDECacheType> jaxbElement = (JAXBElement<XMLCDECacheType>) unmarshallerObject.unmarshal(new FileInputStream(appHome+
                		System.getProperty("file.separator")+ Constants.CDE_CONF_FILE));
			XMLCDECacheType root = jaxbElement.getValue();
			// display the cde details
			List xmlCDEList = root.getXMLCDE();
			/**
			 * Use the iterator.
			 */
			Iterator iterator = xmlCDEList.iterator();
			while(iterator.hasNext())
			{
				XMLCDE xmlCDEObj = (XMLCDE)iterator.next();
				Logger.out.debug("Reading XML CDE Name : "+xmlCDEObj.getName());
				cdeXMLMAP.put(xmlCDEObj.getName(),xmlCDEObj);
			}
			cdeHandler = new CDEHandler(cdeXMLMAP);
        }
		catch( JAXBException je)
		{
			Logger.out.error(je.getMessage(), je);
			throw new Exception("Could not read the"
					+Constants.CDE_CONF_FILE +" XML file : "+je.getMessage());
        }
		catch( IOException ioe )
		{
			Logger.out.error(ioe.getMessage(), ioe);
			throw new Exception("Could not read the"
					+Constants.CDE_CONF_FILE +" XML file IO Error : "+ioe.getMessage());
        }
	}
	/**
	 * Retrieves live CDEs from the caDSR and updates the database cache.
	 * @throws Exception throw Exception
	 */
	public void refreshCache() throws Exception
	{
		CDECacheManager cdeCacheManager = new CDECacheManager();
		cdeCacheManager.refresh(cdeXMLMAP);
		loadCDEInMemory();
	}
	/**
	 * Populates the �in-memory cache� from the �database cache�. The loading
	 * operation will be performed at application startup time. For faster startup
	 * time of the application, all CDE�s can be configured for lazy loading at
	 * the application level as well as individual CDE level. In lazy loading,
	 * required CDE�s will be loaded in-memory in first call to that CDE.
	 * @throws Exception throw Exception
	 */
	private void loadCDEInMemory() throws Exception
	{
		Logger.out.debug("Loading the CDEs in in memory");
		cdeHandler.loadCDE();
	 }
	/**
	 * @param CDEName String parameter.
	 * @return Returns CDE for given CDE Name.
	 */
	public CDE getCDE(String CDEName)
	{
		return cdeHandler.retrieve(CDEName);
	}
	/**
	 * @param cdeName Name of the CDE
	 * @param otherValue NameValueBean object.
	 * @return List of PermissibleValues of a CDE.
	 */
	public List getPermissibleValueList(String cdeName, NameValueBean otherValue)
	{
		List list = new ArrayList();
		CDE cde = getCDE(cdeName);
		if(cde!=null)
		{
			Iterator iterator = cde.getPermissibleValues().iterator();
			while(iterator.hasNext())
			{
				PermissibleValue permissibleValue = (PermissibleValue)iterator.next();
				List pvList = loadPermissibleValue(permissibleValue);
				list.addAll(pvList);
			}
		}
		Collections.sort(list);
		list.add(0,new NameValueBean(Constants.SELECT_OPTION,"-1"));
//		if(otherValue!=null)
//			list.add(1,otherValue);
		return list;
	}
	/**
	 *
	 * @param permissibleValue PermissibleValue object.
	 * @return List object
	 */
	private List loadPermissibleValue(PermissibleValue permissibleValue)
	{
		List pvList = new ArrayList();
		String value = permissibleValue.getValue();
		pvList.add(new NameValueBean(value,value));
		Iterator iterator = permissibleValue.getSubPermissibleValues().iterator();
		while(iterator.hasNext())
		{
			PermissibleValue subPermissibleValue = (PermissibleValue)iterator.next();
			List subPVList = loadPermissibleValue(subPermissibleValue);
			pvList.addAll(subPVList);
		}
		return pvList;
	}
	/**
	 *
	 * @param cdeName String parameter
	 * @param value String parameter
	 * @return String parameter
	 */
	public String getSubValueStr(String cdeName, String value) // NOPMD
	{
		List list = new ArrayList();
		CDE cde = getCDE(cdeName);
		boolean isParentFound = false;
		Iterator iterator = cde.getPermissibleValues().iterator();
		while(iterator.hasNext())
		{
			PermissibleValue permissibleValue = (PermissibleValue)iterator.next();
			if(value.equals(permissibleValue.getValue()))
			{
				Logger.out.debug("permissibleValue "+permissibleValue.getValue());
				isParentFound = true;
				List pvList = loadPermissibleValue(permissibleValue, isParentFound, value);
				list.addAll(pvList);
				break;
			}
			else
			{
				List pvList = loadPermissibleValue(permissibleValue, isParentFound, value);
				if(!pvList.isEmpty())
				{
					isParentFound = true;
					list.addAll(pvList);
					break;
				}
			}
		}
		Logger.out.debug("list "+list.size());
		Logger.out.debug(list);
		StringBuffer buff = new StringBuffer("(");
		Iterator itr = list.iterator();
		while(itr.hasNext())
		{
			String val = (String)itr.next();
			val = val.replaceAll("'","''");
			buff.append("'"+val+"'");
			if(itr.hasNext())
			{
				buff.append(",");
			}
			else
			{
				buff.append(")");
			}
		}
		Logger.out.debug(buff);
		return buff.toString();
	}
	/**
	 *
	 * @param permissibleValue PermissibleValue object
	 * @param isParentFound boolean value
	 * @param value String parameter
	 * @return List object
	 */
	private List loadPermissibleValue(PermissibleValue permissibleValue, // NOPMD
				boolean isParentFound, String value) // NOPMD
	{
		List pvList = new ArrayList();
		if(isParentFound)
		{
			pvList.add(permissibleValue.getValue());
		}
		Iterator iterator = permissibleValue.getSubPermissibleValues().iterator();
		while(iterator.hasNext())
		{
			PermissibleValue subPermissibleValue = (PermissibleValue)iterator.next();
			if(isParentFound)
			{
				List subPVList = loadPermissibleValue(subPermissibleValue, isParentFound, value);
				pvList.addAll(subPVList);
			}
			else
			{
				if(value.equals(subPermissibleValue.getValue()))
				{
					Logger.out.debug(value);
					isParentFound = true;
					List subPVList = loadPermissibleValue
					(subPermissibleValue, isParentFound, value);
					pvList.addAll(subPVList);
					break;
				}
				else
				{
					List subPVList = loadPermissibleValue
					(subPermissibleValue, isParentFound, value);
					if(!subPVList.isEmpty())
					{
						pvList.addAll(subPVList);
						isParentFound = true;
						break;
					}
				}
			}
		}
		return pvList;
	}
	/**
	 *
	 * @param args String array object.
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception
	{
		//Logger.configure("Application.properties");
//		Logger.out = org.apache.log4j.Logger.getLogger("");
//		PropertyConfigurator.configure(Variables.catissueHome+"
		//\\WEB-INF\\src\\"+"ApplicationResources.properties");

		CDEManager.init();
//		CDEManager aCDEManager = new CDEManager();
//		aCDEManager.refreshCache();
	}
}