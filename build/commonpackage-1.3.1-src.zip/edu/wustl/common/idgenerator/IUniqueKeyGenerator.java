package edu.wustl.common.idgenerator;


public interface IUniqueKeyGenerator
{
	public String getKey();
}
