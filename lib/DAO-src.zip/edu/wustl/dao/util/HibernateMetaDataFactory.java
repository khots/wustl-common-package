package edu.wustl.dao.util;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.cfg.Configuration;


public class HibernateMetaDataFactory
{
	public static final Map<String, HibernateMetaData> metaDataCache=new HashMap<String, HibernateMetaData>();
	
	public static final void setHibernateMetaData(String appName, Configuration cfg)
	{
		HibernateMetaData hibernateMetaData=metaDataCache.get(appName);
		if(hibernateMetaData==null)
		{
			hibernateMetaData=new HibernateMetaData(cfg);
			metaDataCache.put(appName, hibernateMetaData);
		}
	}
	
	public static HibernateMetaData getHibernateMetaData(String appName)
	{
		HibernateMetaData metadata;
		if(appName!=null)
		{
			metadata=metaDataCache.get(appName);
		}
		else
		{
			metadata=null;
		}
		return metadata;
	}
	
}
