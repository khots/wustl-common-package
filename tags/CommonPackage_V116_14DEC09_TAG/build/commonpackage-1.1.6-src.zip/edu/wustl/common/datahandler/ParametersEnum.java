
package edu.wustl.common.datahandler;
/**
 *
 * @author
 *
 */
public enum ParametersEnum
{
	/**
	 *
	 */
	BUFFERSIZE, DELIMITER
};
