package edu.wustl.common.datahandler;


public enum HandlerTypeEnum
{
	TEXT, CSV, EXCELSHEET, EXCELSHEET_FOR_LARGE_DATA
};
