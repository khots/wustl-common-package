
package edu.wustl.common.datahandler;

public enum ParametersEnum
{
	BUFFERSIZE, DELIMITER, SHEET_NAME, SHEET_NAMES
};
